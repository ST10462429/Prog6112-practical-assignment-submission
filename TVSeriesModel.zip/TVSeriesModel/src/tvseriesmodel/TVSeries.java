package tvseriesmodel;

import java.util.ArrayList; //import array list ,store list 
import java.util.Scanner;
import tvseriesmodel.TVSeriesModel; //import other class 


// Main public class to handle tv series operations
public class TVSeries {
    ArrayList<TVSeriesModel> seriesList = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    //display menu 
    public void displayMenu() {
        System.out.println("LATEST SERIES - 2025");
        System.out.println("**********************************************");
        System.out.println("Enter 1 to launch menu or another key to exit");

        /// get input 
        String input = scanner.nextLine();
        if (input.equals("1")) {
            showMainMenu();
        } else {
            exitApplication(); // leave application if users does not choose 1 
        }
    }
    //getter 
public ArrayList<TVSeriesModel> getSeriesList() {
    return seriesList;
}
///setter 
public void setSeriesList(ArrayList<TVSeriesModel> list) {
    this.seriesList = list;
}
//display and loop 
    private void showMainMenu() {
        while (true) {
            System.out.println("\nPlease select one of the following menu option:");
            System.out.println("(1) Capture a new series.");
            System.out.println("(2) Search for a series.");
            System.out.println("(3) Update series age restriction");
            System.out.println("(4) Delete a series.");
            System.out.println("(5) Print series report - 2025");
            System.out.println("(6) Exit Application.");

            String choice = scanner.nextLine();
///user choice handling 
            switch (choice) {
                case "1":
                    captureSeries();
                    break;
                case "2":
                    searchSeries();
                    break;
                case "3":
                    updateSeries();
                    break;
                case "4":
                    deleteSeries();
                    break;
                case "5":
                    seriesReport();
                    break;
                case "6":
                    exitApplication();
                    return;
                default:
                    System.out.println("Invalid choice! try again.");
            }
// if user wants menu again 
            System.out.println("Enter 1 to launch menu or any other key to exit");
            String continueChoice = scanner.nextLine();
            if (!continueChoice.equals("1")) {
                /// exit loop 
                break; 
            }
        }
    }
// method to add a new series 
    public void captureSeries() {
        System.out.println("\nCAPTURE A NEW SERIES");
        System.out.println("***********");

        System.out.print("Enter the series id: ");
        String id = scanner.nextLine(); //read user ID

        System.out.print("Enter the series name: ");
        String name = scanner.nextLine();

        String age = getValidAge();

        System.out.print("Enter the number of episodes for " + name + ": ");
        String episodes = scanner.nextLine();

        //new tv series object 
        TVSeriesModel newSeries = new TVSeriesModel(id, name, age, episodes);
        seriesList.add(newSeries);

        System.out.println("processed successfully!!!");
    }
//validate age 
    private String getValidAge() {
        while (true) {
            System.out.print("Enter the series age restriction: ");
            String age = scanner.nextLine();

            try {
                int ageValue = Integer.parseInt(age);
                //chech if within age restriction 
                if (ageValue >= 2 && ageValue <= 18) {
                    return age;
                } else {
                    System.out.println("You have entered an incorrect age!!!");
                    System.out.print("Please re-enter the age: ");
                }
            } catch (NumberFormatException e) {
                System.out.println("You have entered an incorrect series age!!!");
                System.out.print("Please re-enter the series age >> ");
            }
        }
    }
//method to search for series 
    public void searchSeries() {
        System.out.print("\nEnter the series id to search: ");
        String searchId = scanner.nextLine();

        boolean found = false;
        for (TVSeriesModel series : seriesList) {
            if (series.seriesId.equals(searchId)) {
                displaySeriesDetails(series); //show series details 
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("--");
            System.out.println("Series with Series Id: " + searchId + " was not found!");
            System.out.println("--");
        }
    }
/// display details 
    private void displaySeriesDetails(TVSeriesModel series) {
        System.out.println("*************");
        System.out.println("SERIES ID: " + series.seriesId);
        System.out.println("SERIES NAME: " + series.seriesName);
        System.out.println("SERIES AGE RESTRICTION: " + series.seriesAge);
        System.out.println("SERIES NUMBER OF EPISODES: " + series.seriesNumberOfEpisodes);
        System.out.println("--");
    }
// method to update series that is already there 
    public void updateSeries() {
        System.out.print("\nEnter the series id to update: ");
        String updateId = scanner.nextLine();

        boolean found = false;
        for (TVSeriesModel series : seriesList) {
            if (series.seriesId.equals(updateId)) {
                System.out.print("Enter the series name: ");
                series.seriesName = scanner.nextLine();

                series.seriesAge = getValidAge();

                System.out.print("Enter the number of episodes: ");
                series.seriesNumberOfEpisodes = scanner.nextLine();

                System.out.println("Series updated successfully!");
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Series with ID " + updateId + " not found!");
        }
    }
///method to delete 
    public void deleteSeries() {
        System.out.print("\nEnter the series id to delete: ");
        String deleteId = scanner.nextLine();

        boolean found = false;
        for (int i = 0; i < seriesList.size(); i++) {
            if (seriesList.get(i).seriesId.equals(deleteId)) {
                System.out.print("Are you sure you want to delete series " + deleteId + " from the system? Yes (y) to delete: ");
                String confirm = scanner.nextLine();

                if (confirm.equalsIgnoreCase("y")) {
                    seriesList.remove(i);
                    System.out.println("---");
                    System.out.println("Series with Series Id: " + deleteId + " was deleted!");
                    System.out.println("---");
                } else {
                    System.out.println("Deletion cancelled.");
                }
                found = true;
                break;
            }
        }

        if (!found) {
            System.out.println("Series with ID " + deleteId + " not found!");
        }
    }
//method to print series 
    public void seriesReport() {
        if (seriesList.isEmpty()) {
            System.out.println("No series is available to display.");
            return;
        }

        for (int i = 0; i < seriesList.size(); i++) {
            TVSeriesModel series = seriesList.get(i);
            System.out.println("Series " + (i + 1));
            System.out.println("**************");
            System.out.println("SERIES ID: " + series.seriesId);
            System.out.println("SERIES NAME: " + series.seriesName);
            System.out.println("SERIES AGE RESTRICTION: " + series.seriesAge);
            System.out.println("NUMBER OF EPISODES: " + series.seriesNumberOfEpisodes);
            System.out.println("***********");
        }
    }
//method to leave app
    public void exitApplication() {
        System.out.println("Exiting the application... Goodbye!");
        scanner.close();
        System.exit(0);
    }

/// junit test methods 
    public boolean updateSeriesById(String id, String newName, String newAge, String newEpisodes) {
        for (TVSeriesModel series : seriesList) {
            if (series.seriesId.equals(id)) {
                series.seriesName = newName;
                series.seriesAge = newAge;
                series.seriesNumberOfEpisodes = newEpisodes;
                return true;
            }
        }
        return false;
    }

    public boolean deleteSeriesById(String id) {
        for (int i = 0; i < seriesList.size(); i++) {
            if (seriesList.get(i).seriesId.equals(id)) {
                seriesList.remove(i);
                return true;
            }
        }
        return false;
    }

    public boolean isValidAge(String age) {
        try {
            int ageValue = Integer.parseInt(age);
            return ageValue >= 2 && ageValue <= 18;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
