import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import transportnetwork.Bus;
import transportnetwork.Route;
import transportnetwork.TransportNetwork;

public class TransportNetworkTest {

    private TransportNetwork network;
    private Bus bus1;
    private Bus bus2;
    private Route route1;
    private Route route2;

    @Before
    public void setup() {
        // Initialize TransportNetwork
        network = new TransportNetwork("City Transit Authority");

        // Create Routes
        route1 = new Route("R001", "Station A", "Station B", 10.0, 2.5);
        route2 = new Route("R002", "Station C", "Station D", 15.0, 3.0);

        network.addRoute(route1);
        network.addRoute(route2);

        // Create Buses
        bus1 = new Bus("B001", 50, "R001", "Diesel");
        bus2 = new Bus("B002", 40, "R002", "Electric");

        network.addVehicle(bus1);
        network.addVehicle(bus2);
    }

    @Test
    public void testAddVehicle() {
        assertEquals("Vehicle count should be 2", 2, network.vehiclesCount());
    }

    @Test
    public void testAddRoute() {
        assertEquals("Route count should be 2", 2, network.routesCount());
    }

    @Test
    public void testRecordPassengerCount() {
        network.recordPassengerCount("B001", 30);
        assertEquals("B001 total passengers should be 30", 30, bus1.getTotalPassengers());

        network.recordPassengerCount("B002", 20);
        assertEquals("B002 total passengers should be 20", 20, bus2.getTotalPassengers());
    }

    @Test
    public void testPassengerExceedCapacity() {
        network.recordPassengerCount("B001", 60); // exceeds capacity
        assertEquals("B001 should not record passengers exceeding capacity", 0, bus1.getTotalPassengers());
    }

    @Test
    public void testAverageOccupancy() {
        network.recordPassengerCount("B001", 25);
        network.recordPassengerCount("B001", 35);
        double expected = ((25 + 35) / 2.0) / 50 * 100;
        assertEquals("Average occupancy should match calculation", expected, bus1.getAverageOccupancy(), 0.01);
    }

    @Test
    public void testTotalRevenue() {
        network.recordPassengerCount("B001", 20);
        network.recordPassengerCount("B002", 30);
        double expectedRevenue = 20 * route1.getFare() + 30 * route2.getFare();
        assertEquals("Total revenue should match calculation", expectedRevenue, network.calculateTotalRevenue(), 0.01);
    }
}