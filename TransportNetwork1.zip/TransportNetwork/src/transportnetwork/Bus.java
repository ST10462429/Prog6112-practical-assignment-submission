package transportnetwork;

public class Bus extends Vehicle {
    private String fuelType;

    public Bus(String id, int capacity, String routeCode, String fuelType) {
        super(id, capacity, routeCode);
        this.fuelType = fuelType;
    }

    public String getFuelType() { return fuelType; }

 
    public String getVehicleType() { return "Bus"; }

    @Override
    public String toString() {
        return super.toString() + ", Fuel Type: " + fuelType;
    }
}
