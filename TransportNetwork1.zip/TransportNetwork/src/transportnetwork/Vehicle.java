package transportnetwork;

public abstract class Vehicle {
    private String id;
    private int capacity;
    private String routeCode;
    private int[] passengerCounts;
    private int countIndex;

    public Vehicle(String id, int capacity, String routeCode) {
        this.id = id;
        this.capacity = capacity;
        this.routeCode = routeCode;
        this.passengerCounts = new int[7]; // Track passengers for a week
        this.countIndex = 0;
    }

    // Getters
    public String getId() { return id; }
    public int getCapacity() { return capacity; }
    public String getRouteCode() { return routeCode; }

    // Record passenger counts
    public void recordPassengers(int count) {
        if (countIndex >= passengerCounts.length) {
            int[] newCounts = new int[passengerCounts.length * 2];
            System.arraycopy(passengerCounts, 0, newCounts, 0, passengerCounts.length);
            passengerCounts = newCounts;
        }
        passengerCounts[countIndex++] = count;
    }

    public double getAverageOccupancy() {
        if (countIndex == 0) return 0;
        double total = 0;
        for (int i = 0; i < countIndex; i++) {
            total += passengerCounts[i];
        }
        return (total / countIndex) / capacity * 100;
    }

    public int getTotalPassengers() {
        int total = 0;
        for (int i = 0; i < countIndex; i++) {
            total += passengerCounts[i];
        }
        return total;
    }

    public abstract String getVehicleType();

    public String toString() {
        return getVehicleType() + " ID: " + id + ", Capacity: " + capacity +
               ", Route: " + routeCode + ", Avg Occupancy: " +
               String.format("%.2R", getAverageOccupancy()) + "%";
    }
}