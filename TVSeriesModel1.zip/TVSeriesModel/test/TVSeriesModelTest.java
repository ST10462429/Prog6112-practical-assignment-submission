import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

import tvseriesmodel.TVSeries;
import tvseriesmodel.TVSeriesModel;

import java.util.ArrayList;

public class TVSeriesModelTest {

    private TVSeries tvSeries;

    @Before
    public void setup() {
        tvSeries = new TVSeries();

        
        ArrayList<TVSeriesModel> testList = new ArrayList<>();
        testList.add(new TVSeriesModel("S01", "Test Series", "10", "5"));
        tvSeries.setSeriesList(testList);
    }

    @Test
    public void testUpdateSeries() {
        boolean updated = tvSeries.updateSeriesById("S01", "Updated Series", "12", "6");
        assertTrue("Series should be updated", updated);
        TVSeriesModel series = tvSeries.getSeriesList().get(0);
        assertEquals("Updated Series", series.seriesName);
        assertEquals("12", series.seriesAge);
        assertEquals("6", series.seriesNumberOfEpisodes);
    }

    @Test
    public void testDeleteSeries() {
        boolean deleted = tvSeries.deleteSeriesById("S01");
        assertTrue("Series should be deleted", deleted);
        assertTrue("Series list should be empty after deletion", tvSeries.getSeriesList().isEmpty());
    }

    @Test
    public void testDeleteSeries_SeriesNotFound() {
        boolean deleted = tvSeries.deleteSeriesById("S999");
        assertFalse("Deletion should fail for non-existent series", deleted);
        assertFalse("Series list should not be empty", tvSeries.getSeriesList().isEmpty());
    }

    @Test
    public void testSeriesAgeRestriction_AgeValid() {
        assertTrue(tvSeries.isValidAge("2"));
        assertTrue(tvSeries.isValidAge("10"));
        assertTrue(tvSeries.isValidAge("18"));
    }

    @Test
    public void testSeriesAgeRestriction_SeriesAgeInvalid() {
        assertFalse(tvSeries.isValidAge("1"));
        assertFalse(tvSeries.isValidAge("19"));
        assertFalse(tvSeries.isValidAge("abc"));
        assertFalse(tvSeries.isValidAge("-5"));
    }
}
