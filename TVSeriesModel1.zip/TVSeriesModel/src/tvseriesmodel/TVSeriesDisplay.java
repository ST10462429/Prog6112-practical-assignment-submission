
package tvseriesmodel;

public class TVSeriesDisplay {
    
    /// Main class to run the application
    
public class SeriesModel{
    public static void main(String[] args) {
        TVSeries seriesApp = new TVSeries();
        seriesApp.displayMenu();
    }
}
}

