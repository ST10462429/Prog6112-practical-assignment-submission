package transportnetwork;

public class Route {
    private String code;
    private String startLocation;
    private String endLocation;
    private double distance;
    private double fare;

    public Route(String code, String startLocation, String endLocation, double distance, double fare) {
        this.code = code;
        this.startLocation = startLocation;
        this.endLocation = endLocation;
        this.distance = distance;
        this.fare = fare;
    }

    // Getters
    public String getCode() { return code; }
    public String getStartLocation() { return startLocation; }
    public String getEndLocation() { return endLocation; }
    public double getDistance() { return distance; }
    public double getFare() { return fare; }

   
    public String toString() {
        return "Route: " + code + ", From: " + startLocation + " to " + endLocation +
               ", Distance: " + distance + "km, Fare: R" + fare;
    }
}