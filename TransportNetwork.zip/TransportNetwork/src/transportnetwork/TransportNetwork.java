
package transportnetwork;


import java.util.Scanner;

///main class 
public class TransportNetwork {
    private String name;
    private Vehicle[] vehicles;
    private Route[] routes;
    private int vehicleCount;
    private int routeCount;
///constructor to intialize a new transportnetwork
    public TransportNetwork(String name) {
        this.name = name;
        this.vehicles = new Vehicle[10];
        this.routes = new Route[10];
        this.vehicleCount = 0;
        this.routeCount = 0;
    }

    public void addVehicle(Vehicle vehicle) {
        //method to add a new vehicle to network 
        if (vehicleCount >= vehicles.length) {
            // check if vehicle is full
            Vehicle[] newVehicles = new Vehicle[vehicles.length * 2];
            System.arraycopy(vehicles, 0, newVehicles, 0, vehicles.length);
            //copy existing vehicles to new array 
            vehicles = newVehicles;
        }
        // add vehicle to array and increment counter 
        vehicles[vehicleCount++] = vehicle;
        System.out.println("Vehicle added successfully.");
        //confirmation message 
    }

    public void addRoute(Route route) {
        // method to add a new route ti the network 
        if (routeCount >= routes.length) {
            ///check new array with double the capacity 
            Route[] newRoutes = new Route[routes.length * 2];
            System.arraycopy(routes, 0, newRoutes, 0, routes.length);
            //copy existing routes 
            routes = newRoutes;
            
        }
        routes[routeCount++] = route;
        /// add route to array and increment counter 
        System.out.println("Route added successfully.");
        //confirmation message 
    }

    public void recordPassengerCount(String vehicleId, int passengers) {
        
        /// method to record passager count for a specific vehicle 
        Vehicle vehicle = findVehicle(vehicleId);
        if (vehicle != null) {
            // find the vehicle by ID 
            if (passengers <= vehicle.getCapacity()) {
                vehicle.recordPassengers(passengers);
                System.out.println("Passenger count recorded successfully.");
            } else {
                System.out.println("Passenger count exceeds vehicles capacity.");
            }
        } else { 
            //error message 
            System.out.println("Vehicle was not found.");
        }
    }
//helping method to find a vechile by its ID 
    private Vehicle findVehicle(String id) {
        for (int i = 0; i < vehicleCount; i++) {
            /// LOOP 
            if (vehicles[i].getId().equals(id)) return vehicles[i];
            // RETURN VEHICLE IF ID MATCHES 
        }
        return null; // VEHICLE NOT FOUND 
    }

    private Route findRoute(String code) {
        for (int i = 0; i < routeCount; i++) {
            if (routes[i].getCode().equals(code)) return routes[i];
            
        }
        return null; //RETURN NULL
    }

    ///METHOD TO GENERATE A COMPREHENSIVE REPORT 
    public void generateReport() {
        //DISPALY 
        System.out.println("\n= TRANSPORT NETWORK REPORT: " + name + " =");
        System.out.println("Total Vehicles: " + vehicleCount);
        System.out.println("Total Routes: " + routeCount);

        //INITIALIZING REVENUE COUNTER 
        double totalRevenue = 0;
        //LOOP THROUGH ALL VEHICLES 
        for (int i = 0; i < vehicleCount; i++) {
            Vehicle v = vehicles[i];
            Route r = findRoute(v.getRouteCode());
            //Calculate revenue 
            if (r != null) totalRevenue += v.getTotalPassengers() * r.getFare();
        }
        System.out.println("Estimated Total Revenue: R" + String.format("%.R2", totalRevenue));

        System.out.println("\n-- VEHICLE DETAILS --");
        /// VEHICLE DETAILS 
        for (int i = 0; i < vehicleCount; i++) System.out.println(vehicles[i]);

        System.out.println("\n--- ROUTE LIST ---");
        for (int i = 0; i < routeCount; i++) System.out.println(routes[i]);

        System.out.println("\n--- VEHICLES WITH LOW OCCUPANCY (<30%) ---");
        // FLAg to track if any low occupancy vehicles have been found 
        boolean lowFound = false;
        for (int i = 0; i < vehicleCount; i++) {
            if (vehicles[i].getAverageOccupancy() < 30) {
                // print vehicle details 
                System.out.println(vehicles[i]);
                lowFound = true;
            }
        }
        if (!lowFound) System.out.println("No vehicles with low occupancy.");
    }
public int vehiclesCount() {
    return vehicleCount;
}

public int routesCount() {
    return routeCount;
}

public double calculateTotalRevenue() {
    double totalRevenue = 0;
    for (int i = 0; i < vehicleCount; i++) {
        Vehicle v = vehicles[i];
        Route r = findRoute(v.getRouteCode());
        if (r != null) totalRevenue += v.getTotalPassengers() * r.getFare();
    }
    return totalRevenue;
}
    // Main method to run console application
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TransportNetwork network = new TransportNetwork("City Transit Authority");

        boolean running = true;
        while (running) {
            ///display main menu 
            System.out.println("\n=== Public Transport Management System ===");
            System.out.println("1. Add Bus");
            System.out.println("2. Add Route");
            System.out.println("3. Record Passenger Count");
            System.out.println("4. Generate Report");
            System.out.println("5. Exit");
            System.out.print("Select an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
//check user input 
            switch (choice) {
                case 1:
                    System.out.print("Enter Bus ID: ");
                    String id = scanner.nextLine();
                    System.out.print("Enter Capacity: ");
                    int capacity = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Route Code: ");
                    String routeCode = scanner.nextLine();
                    System.out.print("Enter Fuel Type: ");
                    String fuelType = scanner.nextLine();
                    network.addVehicle(new Bus(id, capacity, routeCode, fuelType));
                    break;

                case 2:
                    System.out.print("Enter Route Code: ");
                    String code = scanner.nextLine();
                    System.out.print("Enter Start Location: ");
                    String start = scanner.nextLine();
                    System.out.print("Enter End Location: ");
                    String end = scanner.nextLine();
                    System.out.print("Enter Distance (km): ");
                    double distance = scanner.nextDouble();
                    System.out.print("Enter Fare: ");
                    double fare = scanner.nextDouble();
                    scanner.nextLine();
                    network.addRoute(new Route(code, start, end, distance, fare));
                    break;

                case 3:
                    System.out.print("Enter Vehicle ID: ");
                    String vid = scanner.nextLine();
                    System.out.print("Enter Passenger Count: ");
                    int passengers = scanner.nextInt();
                    scanner.nextLine();
                    network.recordPassengerCount(vid, passengers);
                    break;

                case 4:
                    network.generateReport();
                    break;

                case 5:
                    //exit
                    running = false;
                    break;

                default:
                    System.out.println("Invalid option. Try again.");
            }
        }
        scanner.close();
    }
}